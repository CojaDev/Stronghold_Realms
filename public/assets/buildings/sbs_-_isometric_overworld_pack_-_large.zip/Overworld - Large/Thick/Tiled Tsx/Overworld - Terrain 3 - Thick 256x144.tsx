<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.5" tiledversion="1.6.0" name="Overworld - Terrain 3 - Thick 256x144" tilewidth="256" tileheight="144" tilecount="18" columns="3">
 <image source="../Overworld - Terrain 3 - Thick 256x144.png" trans="ff00ff" width="768" height="864"/>
</tileset>
